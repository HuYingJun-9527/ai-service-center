//package com.hyj.aicodehelper.init;
//
//import dev.langchain4j.community.model.dashscope.QwenChatModel;
//import dev.langchain4j.model.chat.ChatModel;
//import dev.langchain4j.model.chat.listener.ChatModelListener;
//import jakarta.annotation.Resource;
//import lombok.Data;
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import java.util.List;
//
//@Data
//@Configuration
//@ConfigurationProperties(prefix = "langchain4j.community.dashscope.chat-model")
//public class QwenChatModelConfig {
//
//    private String modelName;
//
//    private String apiKey;
//
//    @Resource
//    private ChatModelListener chatModelListener;
//
//    @Bean
//    public ChatModel myQwenChatModel() {
//        return QwenChatModel.builder()
//                .modelName(modelName)
//                .apiKey(apiKey)
//                .listeners(List.of(chatModelListener))
//                .build();
//    }
//}
